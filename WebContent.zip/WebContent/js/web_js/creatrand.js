function creatrand(){
	//var min=1000;
	//var max=9999;
	//var res=Math.floor(min+Math.random()*(max-min));
	//document.write("您得到的签到码是:");
	//document.write(res);
	document.getElementById("startpeople").innerHTML = 1;
}